#include "Rules.h"

int main(int argc, char const *argv[])
{
    Rules rules;
    rules.inputFunction();
    return 0;
}
